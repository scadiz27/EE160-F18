/*      File : presults.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 

/* define for use without the display */ 
//#define DISPLAY

#include <stdio.h>

#include "presults.h"
#include "display.h"
#include "chrutil.h"
#include "exponent.h"

//#define DEBUG1 //Test weight()
//#define DEBUG2 //Test supress_msd()

void put_result(int ans)
/*  This function is given an integer and prints it one digit at a time
	either to the calc display or the stdout.
*/
{  int wt;	/*  the weight of the msd  */
	int zero=0; //Number of zeros that need to be printes
	
	/*  if the integer is 0, print it and return  */
	if(ans == 0)
	{
		#ifdef DISPLAY
		putchar('0');
		#else
		write_char('0');
		#endif
		return;
	}
	/*  if the integer is negative, print the '-' and make it pos.  */
	if(ans < 0)
	{
		#ifdef DISPLAY
		putchar('-');
		#else
		write_char('-');
		#endif
		ans = -ans;
	}
	/*  find the weight of the msd  */

	wt = weight(ans);
	/*  while there are more digits  */
	while(wt >= 1)
	{	/*  get msd, convert to char, and print it  */
		#ifdef DISPLAY
		putchar(int_to_dig(sig_dig_value(ans,wt)));
		#else
		write_char(int_to_dig(sig_dig_value(ans,wt)));
		#endif
		/*  strip the msd  */
		ans = supress_msd(ans,wt);
		/*  go on to next weight  */
		wt = weight(ans);

	}

}


int sig_dig_value(int n, int wt)
/*  This function is given and integer and the current weight.  It
	returns the integer value of the most significant digit.  */
{  return n/wt; }

int supress_msd(int n, int wt){
/*  This function is given an integer and the current weight.  It
	returns an integer with the most significant digit removed.  */
	
    int i;
    wt=1;
    int x=n;
    int y=wt;
 
    
	//Number of zeros in lead
	int numleadzeros=0;
	while((n/wt) !=0){
	    wt = wt * 10;
	    numleadzeros++;
	}
	y = wt/10;
	numleadzeros--;

	//Lead number: n / weight
	int leadnum = x/(wt/10);

	//Lead number with zeros
	int leadwithzeros;
	leadwithzeros = leadnum * pos_power(10,numleadzeros);

	//Number minus leadwithzeros
	int numberminuslead;
	numberminuslead = x - leadwithzeros;

	//Number of trailing digits
	int numbertraildigits=0;
	wt = 1;
	while((numberminuslead/wt)!=0){
	    wt = wt * 10;
	    numbertraildigits++;
	}
	
	//Number of zeros to be printed
	int numzeros = numleadzeros - numbertraildigits;

	//If all zeros
	if(numberminuslead == 0){
		for(i=0;i<numleadzeros;i++){
			write_char('0');
		}
	} else {
	    for(i=0;i<numzeros; i++){
	        write_char('0');
	    }
	}
	return x%y;
}

int weight(int n)
/*  This function is given an integer.  It returns the weight  (a power
	of 10) of the most significant digit.  */
{  int wt = 1;

	while((n/wt) != 0){
		wt = wt * BASE;
		#ifdef DEBUG1
		printf("wt=%d, n=%d\n",wt, n);
		printf("n/wt=%d\n", n/wt);
		#endif
	}
	wt = wt / BASE;
	#ifdef DEBUG1
	printf("wt to return=%d, n=%d\n",wt, n);
	#endif
	return wt;
}
