/*      File : compute.h        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */

/*  This file contains the prototypes for functions in compute.c  */

int compute_result(int opnd1,char op,int opnd2);
/*  This function is given two integer operands and an character operator.
	it performs the indicated operation and returns the integer 
	result.
*/