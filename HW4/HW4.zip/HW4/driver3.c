/*      File : driver3.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 
/* 
Driver to test ops.c and compute.c
*/

#include <stdio.h>
#include "opnd.h"
#include "chrutil.h"
#include "ops.h"
#include "compute.h"

int main(){
    char ch, op;
    int opnd1, opnd2, result;
    
    while(opnd1!=EOF&&opnd2!=EOF&&op!=EOF){
        printf("Enter first operand (EOF to quit): ");
        scanf("%d",&opnd1);
        if(opnd1==EOF){
            break;
        }

        printf("Enter operator: ");
        scanf(" %c",&op);
        
        printf("Enter second operand: ");
        scanf("%d",&opnd2);
        
        result = compute_result(opnd1,op,opnd2);
        printf("The answer is %d\n", result);
    }
}