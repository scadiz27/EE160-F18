/* test int weight(int n)
*/

#include<stdio.h>
#include "exponent.h"
int main(){
    int i;
    int n=1010;
    int wt=1;
    int j=1;
    putchar('0');
    int x=n;
    int y=wt;
    
    printf("n: %d\n",n);
    
	//Number of zeros in lead - number of zeros in trailing
	int numleadzeros=0;
	while((n/wt) !=0){
	    wt = wt * 10;
	    numleadzeros++;
	}
	
	//wt = wt / 10;
	numleadzeros--;
	printf("numleadzeros: %d\n", numleadzeros);
	printf("wt: %d\n",wt);
	
	y = wt/10;

	//Lead number: n / weight
	int leadnum = x/(wt/10);
	printf("leadnum: %d\n",leadnum);
	
	//Lead number with zeros
	int leadwithzeros;
	leadwithzeros = leadnum * pos_power(10,numleadzeros);
	printf("leadwithzeros: %d\n",leadwithzeros);
	
	//Number minus leadwithzeros
	int numberminuslead;
	numberminuslead = x - leadwithzeros;
	printf("numberminuslead: %d\n",numberminuslead);
	
	int numbertraildigits=0;
	
	wt = 1;
	while((numberminuslead/wt)!=0){
	    wt = wt * 10;
	    numbertraildigits++;
	}
	//numbertraildigits--;
	printf("numbertraildigits: %d\n",numbertraildigits);

	
	int numzeros = numleadzeros - numbertraildigits;
	printf("numberzeros: %d\n",numzeros);
	
	printf("xMODy: %d\n", (x%y));
	
	printf("x: %d, y: %d\n",x,y);
	//If all zeros
	if(numberminuslead == 0){
		for(i=0;i<=numleadzeros;i++){
			putchar('0');
		}
	} else {
	    for(i=0;i< numzeros; i++){
	        putchar('0');
	    }
	}
}