/*      File : exponent.h       *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */


/*  This file contains the prototypes for the functions in exponent.c  */

int is_exp(char ch);
/*  This function is given a character and returns true if it
	is a legal shifted exponent character, false otherwise.
*/

char exp_value(char ch);
/*  This function is given a legal shifted exponent character and converts
	it to its unshifted form, returning the cnverted character.
*/

int pos_power(int b, int e);
/*  This function is given a int base and integer exponent and
	raises the base to the exponent, returning the int result.
*/