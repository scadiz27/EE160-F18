/*      File : driver4.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 
/* 
Driver to test presults.c
*/

#include <stdio.h>
#include "opnd.h"
#include "chrutil.h"
#include "exponent.h"
#include "ops.h"
#include "compute.h"
#include "display.h"
#include "presults.h"

//#define DEBUG1 //Test display
#define DEBUG2 //Test weight() function in presults.c
//#define DEBUG3 //Test suppress_msd
int main(){
	char ch, op;
	int operand1, operand2, result;
	
	#ifdef DEBUG2
	int n = 1010;
	weight(n);
	#endif
	
	#ifdef DEBUG3
	int n = 100;
	int wt;
	wt = weight(n);
	supress_msd(n,wt);
	#endif
	
	#ifdef DEBUG1
	//Initialize the dispaly with a message
	write_message("Results Test");

	//while not quitting 
	while((ch = getchar()) != 'q'){
	
		operand1 = get_opnd(ch);
		write_debug(operand1);
		
		//Get first operator
		op = get_op();
		
		ch = getchar();
		
    	operand2 = get_opnd(ch);
    	write_debug(operand2);

    	
    	result = compute_result(operand1,op,operand2);

		put_result(result);
		
		//Get new line to clear screen
        ch = getchar();
        write_char(ch);
	}

	//write the q character to terminate the dispaly
	write_char(ch);
	#endif
}
