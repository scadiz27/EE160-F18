/*      File : compute.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */


/*  This function is given two integer operands and an character operator.
	it performs the indicated operation and returns the integer 
	result.
*/

#include "compute.h"

int compute_result(int opnd1,char op,int opnd2){
    int answer;
    
    //Addition
    if(op=='+'){
        answer = opnd1 + opnd2;
        return answer;
    }
    
    //Subtraction
    if(op=='-'){
        answer = opnd1 - opnd2;
        return answer;
    }
    
    //Multiplication
    if(op=='x'){
        answer = opnd1 * opnd2;
        return answer;
    }
    
    //Division
    if(op=='/'){
        answer = opnd1 / opnd2;
        return answer;
    }
}
