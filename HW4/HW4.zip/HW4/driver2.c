/*      File : driver2.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */

/*  Driver to test get_opnd()
	Calculates the value of an operand input
	end of input signalled by entering space
*/


#include <stdio.h>
#include "display.h"
#include "exponent.h"
#include "opnd.h"
#include "chrutil.h"

int main(){  
	char ch;
	int operand;

	//Initialize the dispaly with a message
	write_message("Operand Test");

	//while not quitting 
	while((ch = getchar()) != 'q'){
	
		operand = get_opnd(ch);
		write_debug(operand);
		

		//Get new line to clear screen
        ch = getchar();
        write_char(ch);
	}

	//write the q character to terminate the dispaly
	write_char(ch);
}


