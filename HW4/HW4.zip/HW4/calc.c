/*      File : calc.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 
/* 
Driver to test presults.c
*/

#include <stdio.h>
#include "opnd.h"
#include "chrutil.h"
#include "exponent.h"
#include "ops.h"
#include "compute.h"
#include "display.h"

int main(){
	char ch, op;
	int operand1, operand2, result;

	//Initialize the dispaly with a message
	write_message("A SIMPLE CALCULATOR");

	//while not quitting 
	while((ch = getchar()) != 'q'){
	
		//Get first operand (this is the result so far)
		operand1 = get_opnd(ch);
		//write_debug(operand1);
		result = operand1;
		
		//Get first operator
		op = get_op();
		
		//While operator is not '='
		while(op!='='){
			//Get next operand
			ch = getchar();
	    	operand2 = get_opnd(ch);
	    	//write_debug(operand2);
	    	
	    	//Evaluate the operator with the 2 operands
	    	result = compute_result(result,op,operand2);
	    	
	    	//Get next operator
	    	op = get_op();
		}
		
		//Display the result
		put_result(result);
		
		//Get new line to clear screen
        ch = getchar();
        write_char(ch);
	}

	//write the q character to terminate the dispaly
	write_char(ch);
}
