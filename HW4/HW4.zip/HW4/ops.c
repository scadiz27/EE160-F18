/*      File : ops.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */

/*  This function reads the operator character from the input
	and echos it to dispaly.  It checks the validity of the
	operator and returns it as a character.
*/

#include <stdio.h>
#include "ops.h"
#include "chrutil.h"
#include "display.h"

char get_op(void){
    char op;
    char cha;
    op=getchar();
    //Skip whitespace
    while(op==' '||op=='\n'){
        op=getchar();
    }

    //Check if legal
    if(ILLEGAL_OP(op)){
        write_error("\nError, not a valid operator");
        return ERROR;
    } else {
        write_char(op);
        return op;
    }
}
