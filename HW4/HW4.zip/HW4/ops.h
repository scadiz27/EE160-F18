/*      File : ops.h        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */

/*  This file contains the prototypes for funcitons in ops.c  */

#define ILLEGAL_OP(c)  (((c) != '+')&&((c) != '-')&&((c) != 'x')&&((c) != '/')\
                        && ((c) != '='))

char get_op(void);
/*  This function reads the operator character from the input
	and echos it to dispaly.  It checks the validity of the
	operator and returns it as a character.
*/