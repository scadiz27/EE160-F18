/*      File : tfdef.h        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 
 
#define TRUE 1
#define FALSE 0


