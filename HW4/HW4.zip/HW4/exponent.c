/*      File : exponent.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */

/* Given: float base and integer exponent
    Outputs: base raised to exponent */
    
#include "exponent.h"  
#include "tfdef.h"
#include <stdio.h>

//#define DEBUG


/*  This function is given a character and returns true (1) if it
	is a legal shifted exponent character, false (0) otherwise.
*/
int is_exp(char ch){
    
/*Input = char(Dec)
 1=!(33), 2=@(64), 3=#(35), 4=$(36), 5=%(37), 6=^(94)
 7=&(38), 8=*(42), 9=((40), 0=)(41)
*/
    if(ch==33||ch==64||ch==35||ch==36||ch==37||ch==94||ch==38||ch==42){
        return TRUE;
    }
    if(ch==40||ch==41){
        return TRUE;
    }
    
    //Not a legal shifted exponent character
    return FALSE;
}

/*  This function is given a legal shifted exponent character and converts
	it to its unshifted form, returning the cnverted character.
*/
char exp_value(char ch){
/*Input = char(Dec)
 1=!(33), 2=@(64), 3=#(35), 4=$(36), 5=%(37), 6=^(94)
 7=&(38), 8=*(42), 9=((40), 0=)(41)
 
 Numbers
 0=48 through 9=57
*/

    if(ch==33) return 49;
    if(ch==64) return 50;
    if(ch==35) return 51;
    if(ch==36) return 52;
    if(ch==37) return 53;
    if(ch==94) return 54;
    if(ch==38) return 55;
    if(ch==42) return 56;
    if(ch==40) return 57;
    if(ch==41) return 48;
    
    
}

int pos_power(int base, int exponent){
    int answer=base;
   if(exponent<0){
        return 0;
    }

    if(exponent == 1){
        return base;
    }
    
    if(exponent == 0){
        return 1;
    }
    
    while(exponent>1){
        #ifdef DEBUG
            printf("[exponent.c]base:%.2f, exponent:%d\n", base,exponent);
        #endif
        answer*=base;
        exponent--;
    }
    return answer;
}

