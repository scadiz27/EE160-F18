/*      File : opnd.c        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 12/2/18         */
 
#include <stdio.h>
#include "opnd.h"
#include "exponent.h"
#include "chrutil.h"
#include "display.h"
#include "tfdef.h"

#define NUM 100

int get_opnd(char ch){
	
	int base[NUM]; //Array to hold base digits
	int exponent[NUM]; //Array to hold exponent digits
	int result; //Holds the resulting operand after space is entered
	int expFlag=FALSE; //Flag to see if exponent is entered
	int baseNum=0; //Number of base digits
	int expNum=0; //Number of exponent digits
	int expTotal=0; //Holds total exponent value
	int baseTotal=0; //Holds total base value
	
	//Skip whitespace
	while(!IS_DIGIT(ch)){
		ch=getchar();
	}
	//Write first character
	write_char(ch);
	//If first character is exponent, return error
	if(is_exp(ch)==TRUE){
		write_error("\nError, first digit cannot be exponent");
		return ERROR;
	}
	
	//Repeat until exponent is entered
	while(IS_DIGIT(ch) && is_exp(ch)==FALSE) { 
		//Store base digits
		base[baseNum] = dig_to_int(ch);
		baseNum++;

		//Read next char
		ch = getchar();
		
		//If it is =, exit loop
		if(ch=='='){
			break;
		}
		
		//If it is a exponent, exit base loop
		if(is_exp(ch)==TRUE){
			break;
		}

		//Check if it is a valid digit, if not, error
		if(!IS_DIGIT(ch) && is_exp(ch)==FALSE && ch!=' '){
			write_error("\nError, not a valid digit");
			return ERROR;
		}
		//Check if it is space, signals end of operand input
		if(ch == ' '){
			break;
		}
		
		//Write next character
		write_char(ch);
	}
	
	//Exponent has been entered
	if(is_exp(ch) == TRUE){
		expFlag = TRUE; //An exponent has been entered
		
		//Write first exponent
		write_exp(exp_value(ch));
		//Read exponents until space or error (base entered)
		while(is_exp(ch)==TRUE && ch!=' '){
			
			//Store exponent digits
			exponent[expNum] = dig_to_int(exp_value(ch));
			expNum++;
			
			//Read next char
			ch = getchar();
			
			//If it is =, exit loop
			if(ch=='='){
				break;
			}

			//Check if input is still an exponent and not end of input
			if(is_exp(ch)==FALSE && ch!=' '){
				write_error("\nError, cannot have alternating base exponents");
				return ERROR;
			}
			
			//Check if it is space, signals end of operand input
			if(ch == ' '){
				break;
			}
			
			//Write next exponent
			write_exp(exp_value(ch));
		}
	}
	
	//Here, space has been entered signalling end of operand input
	
	//Calculate base total
	int i;
	int digActual;
	for(i=0;i<baseNum;i++){
		
		//The value of each digit is actually digit^(10*(NumDigits-DigNum))
		//Example, the 2 in 12345 is 2*(10^2)
		digActual=base[i]*pos_power(10,baseNum-(i+1));
		
		baseTotal+=digActual;
	}
	
	//If only one digit, baseTotal = that digit
	if(baseNum==1){
		baseTotal=base[0];
		
	}
	
	//Calculate exponent total (if one was entered)
	if(expFlag == TRUE){
		for(i=0;i<expNum;i++){
			
			//The value of each digit is actually digit^(10*(numDigits-1))
			//Example, the 2 in 1234 is 2*(10^2)
			digActual=exponent[i]*pos_power(10,expNum-(i+1));
			
			expTotal+=digActual;
		}
	} else {
		expTotal=1;
	}
	
	//If exponent only 1 digit, expTotal = that digit
	if(expNum==1){
		expTotal=exponent[0];
	}
	
	//Displace last character
	write_char(ch);
	
	//Calculate operand total
	result=pos_power(baseTotal,expTotal);

	return result;
}

