/*      File : driver1.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */
 
/*
Driver to test setup.c and safe.c
*/

#include <stdio.h>

#include "setup.h"
#include "util.h"

int main(){
    
    int mineLocation[MAXROW][MAXCOL];
    int safeSpots[MAXROW][MAXCOL];
    
    int difficulty = EASY;
    
    setup(difficulty, mineLocation);
    startSafe(mineLocation, safeSpots);
    
    int i, j;
    
    //Run through arrays to check mine placement
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            if(mineLocation[i][j] == YESMINE){
                printf("[FROM MAIN] Mine at row %d, col %d\n",i,j);
            }
        }
    }
    
    printf("\n");
    
    //Run through arrays to check initial safe spots
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            if(safeSpots[i][j] == SAFE){
                printf("[FROM MAIN] Safe at row %d, col %d\n",i,j);
            }
        }
    }
    printf("HI\n");

}