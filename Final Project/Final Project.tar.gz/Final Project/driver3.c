/*      File : driver3.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Driver to test detect() function in detect.c
*/

#include <stdio.h>

#include "setup.h"
#include "util.h"
#include "move.h"
#include <stdlib.h>

#define DEBUG1 //Check mine placement
#define DEBUG2 //Check movement and adjacent mines


int main(){
    
    //Pointers to timmy's position
    int *ypos;
    int *xpos;

    //Timmmy's position (start at 0,0)
    int xtim = 0, ytim = 0;

    //Assign pointer to timmy position
    xpos = &xtim;
    ypos = &ytim;


    int timmy = ALIVE; //Variable for if timmy is alive or not
    char command; //Input command (movement)
    int adjacent; //Number of adjacent mines to timmy
    
    //Mine locations on playing field
    int mineLocation[MAXROW][MAXCOL];
    
    //Safe spot locations on field
    int safeSpots[MAXROW][MAXCOL];
    
    int difficulty = EASY;
    
    setup(difficulty, mineLocation); //Place mines
    startSafe(mineLocation, safeSpots); //Place initial safe spots
    
    int i, j; //Variables for for loops
    
    //Run through arrays to check mine placement
#ifdef DEBUG1
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            if(mineLocation[i][j] == YESMINE){
                printf("[FROM MAIN] Mine at row %d, col %d\n",i,j);
            }
        }
    }
    printf("\n");
#endif
    
    //Loop until quit (q) or steps on mine
    while(command != 'q' && timmy == ALIVE){
        command = getchar();
        
        //Move timmy
        if((move(command, xpos, ypos, mineLocation,safeSpots)) == YESMINE)
        timmy = DEAD;
        
        //Display number of adjacent mines
        adjacent=detect(xpos,ypos,mineLocation);
        
#ifdef DEBUG2
if(command != '\n'){
    printf("[FROM MAIN] ytim:%d, xtim:%d\n",ytim,xtim);
    printf("[FROM MAIN] Number of adjacent mines: %d\n", adjacent);
}
#endif
    }

}