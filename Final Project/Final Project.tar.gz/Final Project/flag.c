/*      File : flag.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Given: Number of flags to be placed, Flag direction, 
        timmy's position (x,y), mine array,flag array
Returns: YESMINE if mine was there, NOMINE if not, or ERROR
Updates number of flags to be placed, and flag array
*/

#include <stdio.h>
#include "util.h"
#include "flag.h"
#include "display.h"

//#define DEBUG1

int flag(int *points,int *numFlags,char dir,int *xpos, int *ypos,
        int mine[][MAXCOL], int flag[][MAXCOL]){
    //Variables for for loop
    int i,j;
    //Save variables pointed to as local variables
    int x=*xpos;
    int y=*ypos;
    int z=*numFlags;
    int point=*points;
  
    //No flags left to be placed
    if(z==0)
        return ERROR;
    
    //Variable whether flag placed on mine
    int mineThere = NOMINE;
    
    //Reject all non flag placement inputs
    switch(dir){
        case 'Y': 
        case 'H': 
        case 'N': 
        case 'I': 
        case 'K': 
        case '<': 
        case 'U': 
        case 'M': break; //Valid input, continue
        default: return ERROR; //Invalid input, don't move
    }
    
    //Exclude movements that place mine out of map
    //Boundaries
    //Top: y=0, Bottom: y=7
    //Left: x=0, Right: x=9
    
    //Moving out to top
    if(y==0){
        if(dir=='Y'||dir=='U'||dir=='I')
        return ERROR; //Don't move
    }
    
    //Moving out to bottom
    if(y==7){
        if(dir=='N'||dir=='M'||dir=='<')
        return ERROR;
    }
    
    //Moving out to left
    if(x==0){
        if(dir=='Y'||dir=='H'||dir=='N')
        return ERROR;
    }
    
    //Moving out to right
    if(x==9){
        if(dir=='I'||dir=='K'||dir=='<')
        return ERROR;
    }
    
    //Place flags (valid input here)
    switch(dir){
        case 'Y': //Up and leftM
            if(flag[y-1][x-1] == NOFLAG){ //If there is no flag there
                
                flag[y-1][x-1] = YESFLAG; //Put flag into array
                if(mine[y-1][x-1] == YESMINE){ //Check if mine is there
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y-1,x-1,0); //Show flag with mine
                    point+=2; //Has mine, increase score
                } else {
                    show_glif(FLAG,y-1,x-1,0); //show flag with no mine
                    point-=2; //If no mine, decrease score
                }
                
                    
                //Decrement flags left to be placed
                z--; 
                break;
            }
        case 'H': //Left
            if(flag[y][x-1] == NOFLAG){
                flag[y][x-1] = YESFLAG;
                if(mine[y][x-1] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y,x-1,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y,x-1,0);
                    point-=2;
                }
                z--;
                break;
            }

        case 'N': //Down and left
            if(flag[y+1][x-1] == NOFLAG){
                flag[y+1][x-1] = YESFLAG;
                if(mine[y+1][x-1] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y+1,x-1,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y+1,x-1,0);
                    point-=2;
                }
                z--;
                break;
            }
        case 'I': //Up and right
            if(flag[y-1][x+1] == NOFLAG){
                flag[y-1][x+1] = YESFLAG;
                if(mine[y-1][x+1] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y-1,x+1,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y-1,x+1,0);
                    point-=2;
                }
                z--;
                break;
            }
        case 'K': //Right
            if(flag[y][x+1] == NOFLAG){
                flag[y][x+1] = YESFLAG;
                if(mine[y][x+1] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y,x+1,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y,x+1,0);
                    point-=2;
                }
                z--;
                break;
            }
        case '<': //Down and right
            if(flag[y+1][x+1] == NOFLAG){
                flag[y+1][x+1] = YESFLAG;
                if(mine[y+1][x+1] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y+1,x+1,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y+1,x+1,0);
                    point-=2;
                }
                z--;
                break;
            }
        case 'U': //Up
            if(flag[y-1][x] == NOFLAG){
                flag[y-1][x] = YESFLAG;
                if(mine[y-1][x] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y-1,x,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y-1,x,0);
                    point-=2;
                }
                z--;
                break;
            }
        case 'M': //Down
            if(flag[y+1][x] == NOFLAG){
                flag[y+1][x] = YESFLAG;
                if(mine[y+1][x] == YESMINE){
                    mineThere = YESMINE;
                    show_glif(FL_MINE,y+1,x,0);
                    point+=2;
                } else {
                    show_glif(FLAG,y+1,x,0);
                    point-=2;
                }
                z--;
                break;
            }
    }
    

    
    //Update number of flags left through pointer
    *numFlags = z;
    *points = point;
    //Return whether flag was put on mine or not
    return mineThere;
    
    
}