/*      File : miensfeld.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */
 
/*
Main driver for miensfeld
*/

#include <stdio.h>

#include "setup.h"
#include "util.h"
#include "move.h"
#include "detect.h"
#include "display.h"
#include <stdlib.h>

//#define DEBUG1 // Show all mines

int main(){
    
    /*** VARIABLES ***/
    int difficulty; //Difficulty variable
    
    int i, j; //Variables for for loops

    int *ypos; //Timmy Y position
    int *xpos; //Timmy X position
    int *flags; //Flags left
    int *points; //Points pointer

    int xtim = 0, ytim = 0; //Timmmy's position (start at 0,0)
    
    int flagsLeft; //Number of flags to be placed
    
    int minesLeft; //Number of mines left to be found
    
    int pointScore = 0; //Score

    xpos = &xtim;
    ypos = &ytim;
    flags = &flagsLeft;
    points = &pointScore; 

    char command; //Input command (movement)
    int adjacent; //Number of adjacent mines to timmy

    
    /*** ARRAYS ***/
    //Mine locations on playing field
    int mineLocation[MAXROW][MAXCOL];
    
    //Safe spot locations on field
    int safeSpots[MAXROW][MAXCOL] = {0};
    
    //Flag locations on field
    int flagLocation[MAXROW][MAXCOL] = {NOFLAG};

    
/*** BEGIN OVERALL GAME LOOP ***/
while(1){
    
    /*** PROMPTS TO BEGIN GAME INSTANCE ***/
    command = '0';
    for(i=0;i<100;i++){
                printf("\n");
            }
    titleScreen(); // Show title screen
    command = getchar();
    
    /*** GET TITLE SCREEN COMMANDS ***/
    while(instructions(command) == 0)
        command = getchar();
    
    /*** RESET VARIABLES FOR NEW GAME ***/
    pointScore = 0;
    xtim = 0;
    ytim = 0;
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            safeSpots[i][j] = 0;
        }
    }
    
    /*** BEGIN NEW GAME INSTANCE ***/
    command = getchar(); //Get difficulty choice
    //Filter bad choices
    while(command!='1'&&command!='2'&&command!='3'&&command!='4')
        command = getchar();
    
    /*** APPLY DIFFICULTY ***/
    if(command == '1')
        difficulty = EASY;
        
    if(command == '2')
        difficulty = MODERATE;
        
    if(command == '3')
        difficulty = HARD;
        
    if(command == '4')
        difficulty = IMPOSSIBLE;
        
    if(command == 'q')
        return 0; //End overall game loop

    /*** SET UP GAME INSTANCE ***/
    for(i=0;i<10;i++)
        printf("\n"); //Make space for game board
    draw_board(); //Display game board
    setup(difficulty, mineLocation); //Place mines
    startSafe(mineLocation, safeSpots); //Place initial safe spots
    flagsLeft = difficulty; //Apply number of flags to be placed
    minesLeft = difficulty; //Apply initial number of mines to be found



    /*** GAME INSTANCE LOOP ***/
    //Put initial timmy
    show_glif(TIMMY,ytim,xtim,detect(xtim,ytim,mineLocation));
    while(command != 'q'){ //While he is alive and no quit

//Show all mines for debugging
#ifdef DEBUG1
for(i=0;i<=ROW;i++){
    for(j=0;j<=COL;j++){
        if(mineLocation[i][j] == YESMINE){
            show_glif(MINE,i,j,0);
        }
    }
}
#endif

        /*** UPDATE SCORE, MINES, FLAGS INDICATOR ***/
        update_score(pointScore);
        update_mines(minesLeft);
        update_flags(flagsLeft);
        
        /*** GET INPUT COMMAND ***/
        command = getchar(); 
        while(command=='\n'){
            command = getchar(); //Get input command
        }
        
        /*** EXIT GAME INSTANCE ***/
        if(command == 'q'){ //Exit game instance if q
            clear_screen();
            break;
        }

        /*** MOVE TIMMY ***/
        if((move(points,command,xpos,ypos,mineLocation,safeSpots,
        flagLocation))==YESMINE){ 
            
            
            /*** TIMMY STEPPED ON A MINE ***/
            
            //Reveal game board
            for(i=0;i<=ROW;i++){
                for(j=0;j<=COL;j++){
                    
                    //Check if there is a mine there
                    if((mineLocation[i][j])==YESMINE)
                        show_glif(MINE,i,j,0);
                        
                    //Check if a flag was put on a mine
                    if((mineLocation[i][j])==YESMINE &&
                    (flagLocation[i][j])==YESFLAG){
                        //Flag was put on mine correctly
                        show_glif(FL_MINE,i,j,0);
                    }
                    
                    //Empty all other spots
                    if((mineLocation[i][j])==NOMINE &&
                    (flagLocation[i][j])==NOFLAG){
                        show_glif(EMPTY,i,j,0);
                    }
                }
            }
                
            show_glif(EXPLODE,ytim,xtim,0); //Timmy stepped on mine
            
            //Check for replay
            write_message(5, "DEAD! Play again? y/n"); //Check for replay
            command = getchar();
            while(command != 'y' && command != 'n')
                command = getchar(); //Disregard invalid input
                
            if(command == 'y'){ //Replay
                clear_screen();
                break;
            }
            if(command == 'n'){ //No replay
                clear_screen(); 
                return 0;
            }
        }

        /*** TIMMY WINS ***/
        if(xtim == COL+1){
            pointScore+=10; //Update points with winning bonus
            
            //Reveal game board
            for(i=0;i<=ROW;i++){
                for(j=0;j<=COL;j++){
                    
                    //Check if there is a mine there
                    if((mineLocation[i][j])==YESMINE)
                        show_glif(MINE,i,j,0);
                        
                    //Check if a flag was put on a mine
                    if((mineLocation[i][j])==YESMINE &&
                    (flagLocation[i][j])==YESFLAG){
                        //Flag was put on mine correctly
                        show_glif(FL_MINE,i,j,0);
                    }
                    
                    //Empty all other spots
                    if((mineLocation[i][j])==NOMINE &&
                    (flagLocation[i][j])==NOFLAG){
                        show_glif(EMPTY,i,j,0);
                    }
                }
            }
            
            //Check for replay
            write_message(5, "WIN! Play again? y/n"); 
            command = getchar();
            while(command != 'y' && command != 'n')
                command = getchar(); //Disregard invalid input
            
            if(command == 'y'){ //Replay
                clear_screen();
                break;
            }
            if(command == 'n'){ //No replay
                clear_screen(); 
                return 0;
            }
        }
        

        /*** PLACING FLAGS ***/
        if((flag(points,flags,command,xpos,ypos,mineLocation,flagLocation))
            ==YESMINE){
            minesLeft--; //Decrement number of mines left to be found
        }
        
    } /*** END OF GAME INSTANCE LOOP ***/
} /*** END OF OVERALL GAME LOOP ***/
clear_screen();
}