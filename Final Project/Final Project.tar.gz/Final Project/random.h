/*      File : random.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */
 
/*
Header for random.c
*/

int random(int n);