/*      File : detect.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Header for detect.c
Given: timmy position, mine location array
Returns: number of adjacent mines
*/

#include "util.h"
#include <stdio.h>

int detect(int xpos, int ypos, int mine[][MAXCOL]);