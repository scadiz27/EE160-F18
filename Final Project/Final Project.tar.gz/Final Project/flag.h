/*      File : flag.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Header file for flag.c
*/

/*
Given: Number of flags to be placed, Flag direction, 
        timmy's position (x,y), mine array,flag array
Returns: YESMINE if mine was there, NOMINE if not, or ERROR
Updates number of flags to be placed, and flag array
*/


int flag(int *points,int *numFlags,char dir,int *xpos, int *ypos,
        int mine[][MAXCOL], int flag[][MAXCOL]);