

#include <stdio.h>

void array(int arr[]);

int main(){
    int array1[10];
    
    int i=0;
    
    for(i=0;i<10;i++){
        array1[i]=1;
    }
    
    for(i=0;i<10;i++){
        printf("[FROM MAIN1], array1[%d] = %d\n", i, array1[i]);
    }
    
    array(array1);
    
    for(i=0;i<10;i++){
        printf("[FROM MAIN2], array1[%d] = %d\n", i, array1[i]);
    }
}



void array(int arr[]){
    int i=0;
    
    for(i=0;i<10;i++){
        arr[i] = 10;
        //printf("[FROM ARRAY], array1[%d] = %d\n", i, array1[i]);
    }
}

