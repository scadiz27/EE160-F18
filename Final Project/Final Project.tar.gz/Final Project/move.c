/*      File : move.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Functions to move Timmy
Also check if he steps onto a flag
Given: Direction to move, Timmy x position, y position
Returns: NOMINE is moved to a safe spot, MINE if onto a mine
Also updates safe spot array
*/

#include "move.h"
#include "util.h"
#include "display.h"
#include <stdio.h>

//#define DEBUG1 //Test movement
//#define DEBUG2 //Test initial location

int move(int *points,char dir,int *xpos,int *ypos,
    int mine[][MAXCOL],int safe[][MAXCOL], int flags[][MAXCOL]){
    
#ifdef DEBUG2
printf("Entering move.c  *xpos=%d, *ypos=%d\n",*xpos,*ypos);
#endif
    
    //Save positions with local variables
    int oldx;
    int oldy;
    int x = *xpos;
    int y = *ypos;
    oldx = x;
    oldy = y;
    int point = *points;
    //Reject all non movement inputs
    switch(dir){
        case 'y': 
        case 'h': 
        case 'n': 
        case 'i': 
        case 'k': 
        case ',': 
        case 'u': 
        case 'm': break; //Valid input, continue
        default: return NOMINE; //Invalid input, don't move
    }
    

    
    
    //Exclude movements that would move out of map
    //Boundaries
    //Top: y=0, Bottom: y=7
    //Left: x=0, Right: x=9
    
    //Moving out to top
    if(y==0){
        if(dir=='y'||dir=='u'||dir=='i')
        return NOMINE; //Don't move
    }
    
    //Moving out to bottom
    if(y==7){
        if(dir=='n'||dir=='m'||dir==',')
        return NOMINE;
    }
    
    //Moving out to left
    if(x==0){
        if(dir=='y'||dir=='h'||dir=='n')
        return NOMINE;
    }


    //Move Timmy (positive Y is down)
    switch(dir){
        case 'y': //Up and left
            x--;
            y--;
            break;
        case 'h': //Left
            x--;
            break;
        case 'n': //Down and left
            x--;
            y++;
            break;
        case 'i': //Up and right
            x++;
            y--;
            break;
        case 'k': //Right
            x++;
            break;
        case ',': //Down and right
            x++;
            y++;
            break;
        case 'u': //Up
            y--;
            break;
        case 'm': //Down
            y++;
            break;
    }
    
    //Prevent Timmy from walking on a flagged mine
    if(flags[y][x] == YESFLAG && mine[y][x] == YESMINE)
        return NOMINE;
        
    //Update variable pointed to
    *xpos = x;
    *ypos = y;

#ifdef DEBUG1
printf("New Location y:%d, x:%d\n", y, x);
printf("New Location *ypos:%d, *xpos:%d\n", *ypos, *xpos);
#endif    


    //Check if he is on a mine or not
    int i, j; //Variables to move through for loops
    
    //Run through mine location array searching for mines
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            
            //Check if Timmy location is on a mine
            if(mine[i][j]==YESMINE && i==y && j==x){
                show_glif(SAFE,oldy,oldx,detect(oldx,oldy,mine));
                return YESMINE; //Return he is on a mine
            }
        }
    }
    
    //At this point, no mine detected on his location
    if(safe[y][x] != YESSAFE){
        safe[y][x] = YESSAFE;
        point++; //Increase score
    }
    
    *points = point;
    
    //Update game board
    //Put safe glif in old spot
    show_glif(SAFE,oldy,oldx,detect(oldx,oldy,mine));
    
    
    //If old spot had a flag there before, put flag back
    if(flags[oldy][oldx] == YESFLAG){
        if(mine[oldy][oldx] == NOMINE){
            show_glif(FLAG,oldy,oldx,0);
        }
    }
    


    //Show updated Timmy location
    show_glif(TIMMY,y,x,detect(x,y,mine));
    
    return NOMINE;
}