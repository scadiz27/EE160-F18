/*      File : detect.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Given: timmy position, mine location array
Returns: number of adjacent mines
*/

#include "util.h"
#include "detect.h"
#include <stdio.h>

int detect(int xpos, int ypos, int mine[][MAXCOL]){
    //Save positions with local variables
    int x = xpos;
    int y = ypos;
    
    //Variables for for loop
    int i, j;
    
    //Number of mines adjacent
    int numAdj = 0;
    
    //Run through mine array
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            
            //Check if mine adjacent to position
            if(mine[i][j] == YESMINE){
                //Mine to Up, Left
                if((y-1) == i && (x-1) == j)
                numAdj++;
                
                //Mine to Up, Right
                if((y-1) == i && (x+1) == j)
                numAdj++;
                
                //Mine to Up
                if((y-1) == i && x == j)
                numAdj++;
                
                //Mine to Down, Left
                if((y+1) == i && (x-1) == j)
                numAdj++;
                
                //Mine to Down, Right
                if((y+1) == i && (x+1) == j)
                numAdj++;
                
                //Mine to Down
                if((y+1) == i && x == j)
                numAdj++;
                
                //Mine to Left
                if(y==i && (x-1) == j)
                numAdj++;
                
                //Mine to Right
                if(y==i && (x+1) == j)
                numAdj++;
            }
        }
    }
    
    //Return number of adjacent mines
    return numAdj;
}