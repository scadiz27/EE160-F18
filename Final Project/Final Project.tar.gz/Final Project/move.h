/*      File : move.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */


/*
Header file for move.c
Given: Direction to move, Timmy x position, y position
Returns: NOMINE is moved to a safe spot, MINE if onto a mine

Updates safe spot array
*/

#include "util.h"

int move(int *points,char dir,int *xpos,int *ypos,
    int mine[][MAXCOL],int safe[][MAXCOL], int flags[][MAXCOL]);