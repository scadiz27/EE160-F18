
void array(int arr[]){
    int i=0;
    
    for(i=0;i<10;i++){
        arr[i] = 10;
        //printf("[FROM ARRAY], array1[%d] = %d\n", i, array1[i]);
    }
}