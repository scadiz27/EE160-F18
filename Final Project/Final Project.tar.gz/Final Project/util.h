/*      File : util.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */
 
/*
Utility file header
*/


//Timmy alive or dead
#define ALIVE 1
#define DEAD 0

//Define map size
#define ROW 7 //Max number rows (8 actual rows 1-8)
#define COL 9 //Number columns (10 actual columns 1-10)

//To define arrays
#define MAXROW 20
#define MAXCOL 20

//To define safe spots
#define YESSAFE 1

//To define flag/no flag
#define YESFLAG 1
#define NOFLAG 0


//Define mine/no mine
#define YESMINE 1
#define NOMINE 0

//Define game modes by number of mines to be placed
#define EASY 6
#define MODERATE 11
#define HARD 16
#define IMPOSSIBLE 20

//Define returning error
#define ERROR 99