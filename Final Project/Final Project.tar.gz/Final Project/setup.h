/*      File : setup.h           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Header file for setup.c
*/

#include "util.h"

//Show title screen
void titleScreen(void);

//Show instruction screens
int instructions(char command);

//Place initial mines based on difficulty
void setup(int difficulty, int mine[][MAXCOL]);

//Starting safe spots
//No more than 20
//Either in far left row, or adjacent to safe spot in a row
void startSafe(int mineLocation[][MAXCOL], int safe[][MAXCOL]);
    