/*      File : setup.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */
 
/*
Contains functions to setup mine field
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "util.h"
#include "setup.h"
#include "display.h"


//#define DEBUG2 //Test random functions
//#define DEBUG1

//#define DEBUG3 //Test random for startSafe
//#define DEBUG4 //Check safe spots

//Place initial mines based on difficulty
void setup(int difficulty, int mine[][MAXCOL]){
    
    int i, j; //Variable for for loops
    
    //Clear arrays
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            mine[i][j] = 0;
        }
    }

    int numMines = difficulty;   //Number of mines to be placed
    
    //GENERATE MINES
    //rand() % (max_number + 1 - minimum_number) + minimum_number
    
    srand(time(NULL)); //Seed random function
    int randRow, randCol; //Random variables for mine placement

    //Loop until number of mines have been places
    for(i=0;i<numMines;){
        
        //Find random row (Number of rows = 8, in array = 7)
        randRow = rand() % 8;

        //Find random column (Number of columns = 10, in array = 9)
        randCol = rand() % 10;
        
#ifdef DEBUG2
printf("Mine #%d, randRow: %d, randCol: %d\n",i,randRow,randCol);
#endif

        //Check if spot doesn't have a mine
        if(mine[randRow][randCol] == NOMINE){
            mine[randRow][randCol] = YESMINE; //Now it does
            
#ifdef DEBUG1
printf("Mine #%d placed at row %d, col %d\n",i, randRow, randCol);
#endif

            //Update mine number index
            i++;
        }
    }
    
}


//Starting safe spots
//No more than 20
//Either in far left Column, or adjacent to safe spot in a row

void startSafe(int mine[][MAXCOL], int safe[][MAXCOL]){
    
    int x=0; //Number of safe spots places
               
    int i, j; //Variables for for loops
    
    
    //Clear array
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            safe[i][j] = 0;
        }
    }
    
    srand(time(NULL)); //Seed random function
    
    
    int spots; //Random number of safe spots (less than 20)
    spots = rand() % 21;

#ifdef DEBUG3
printf("Random number of safe spots: %d\n",spots);
#endif

    //Loop until all safe spots are placed
    while(x<spots){
        
        //Go through arrays, Column+rows, then next column
        for(j=0;j<=COL && x<spots;j++){
            for(i=0;i<=ROW && x<spots;i++){
                
                //If there is a mine, and not already marked safe
                if(mine[i][j] == NOMINE && mine[i][j] != YESSAFE){
                    
                    //If it is in far left column
                    if(j==0){
                        safe[i][j] = YESSAFE; //Mark spot safe
                    show_glif(SAFE,i,j,detect(j,i,mine));
                        x++; //Increment number of safe spots placed
                    }
                    
                    //If it is adjacent to a safe spot in a row
                    if(j != 0 && safe[i][j-1] == YESSAFE){
                        safe[i][j] = YESSAFE; //Mark spot safe
                    show_glif(SAFE,i,j,detect(j,i,mine));
                        x++; //Increment number of safe spots placed
                    }
                }
            }
        }
    }

}

//Show title screen
void titleScreen(void){
    char c;
    //File pointer
    FILE *fptr;
    
    //Open title screen text file
    fptr = fopen("title1", "r");

    //Print title screen
    c = fgetc(fptr);
    while(c != EOF){
        printf("%c", c);
        c=fgetc(fptr);
    }
    
    //Close file
    fclose(fptr);
    printf("Enter choice:");
}

//Show instruction screens
int instructions(char command){
    //printf("[instructions] command: %c\n",command);
    char c;
    
    //File pointers
    FILE *fptr;
    
    //Open correct file
    if(command == '1'){ //Move instructions
        fptr = fopen("move.txt", "r");
        
        //Print move instructions
        c = fgetc(fptr);
        while(c != EOF){
            printf("%c", c);
            c=fgetc(fptr);
        }
        
        //Close file
        fclose(fptr);
        printf("Enter choice:");
        return 0;
    }
    
    //Flag instructions
    if(command == '2'){ 
        fptr = fopen("flags.txt", "r");
        c = fgetc(fptr);
        while(c != EOF){
            printf("%c", c);
            c=fgetc(fptr);
        }
        fclose(fptr);
        printf("Enter choice:");
        return 0;
    }
    
    //Points instructions
    if(command == '3'){ 
        fptr = fopen("points", "r");

        c = fgetc(fptr);
        while(c != EOF){
            printf("%c", c);
            c=fgetc(fptr);
        }
        fclose(fptr);
        printf("Enter choice:");
        return 0;
    }

    //Begin game instance
    if(command == '4'){ 
        fptr = fopen("difficulty", "r");

        c = fgetc(fptr);
        while(c != EOF){
            printf("%c", c);
            c=fgetc(fptr);
        }
        fclose(fptr);
        printf("\n\n\nEnter choice:");
        return 1;
    }
    
    //Invalid input
    return 0;
}