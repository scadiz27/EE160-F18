/*      File : driver4.c           *
 *      By   : Stephen Cadiz           *
 *      login: scadiz27    *
 *      team : Hammahs      *
 *      Date : 12/7/18     */

/*
Driver to test flag placement flag() in flag.c
*/

#include <stdio.h>

#include "setup.h"
#include "util.h"
#include "move.h"
#include <stdlib.h>

#define DEBUG1 //Check mine placement
#define DEBUG2 //Check movement and adjacent mines
#define DEBUG3 //Check difficulty
#define DEBUG4 //Check where flags are
#define DEBUG5 //Check points

int main(){
    
    int difficulty; //Difficulty variable
    
    int i, j; //Variables for for loops
    
    //Pointers
    int *ypos; //Timmy Y position
    int *xpos; //Timmy X position
    int *flags; //Flags left
    int *points; //Points pointer

    int xtim = 0, ytim = 0; //Timmmy's position (start at 0,0)
    
    int flagsLeft; //Number of flags to be placed
    
    int minesLeft; //Number of mines left to be found
    
    int pointScore = 0; //Score

    //Assign pointers
    xpos = &xtim;
    ypos = &ytim;
    flags = &flagsLeft;
    points = &pointScore; 

    int timmy = ALIVE; //Variable for if timmy is alive or not
    char command; //Input command (movement)
    int adjacent; //Number of adjacent mines to timmy
    
    //Mine locations on playing field
    int mineLocation[MAXROW][MAXCOL];
    
    //Safe spot locations on field
    int safeSpots[MAXROW][MAXCOL] = {0};
    
    //Flag locations on field
    int flagLocation[MAXROW][MAXCOL] = {NOFLAG};
    
//Begin overall game loop
while(1){
    //Reset variables
    timmy = ALIVE;
    pointScore = 0;
    xtim = 0;
    ytim = 0;
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            safeSpots[i][j] = 0;
        }
    }
    
    //Get difficulty choice
    printf("Enter difficulty or 0 to quit\n");
    command = getchar();
    
    //Filter bad choices
    while(command!='1'&&command!='2'&&command!='3'&&command!='4'){
        if(command!='\n'){
            printf("Invalid choice. Enter difficulty or 0 to quit\n");
        }
        command = getchar();
    }
    
    if(command == '1')
        difficulty = EASY;
        
    if(command == '2')
        difficulty = MODERATE;
        
    if(command == '3')
        difficulty = HARD;
        
    if(command == '4')
        difficulty = IMPOSSIBLE;
        
    if(command == '0')
        return 0; //End overall game loop

#ifdef DEBUG3
printf("Difficulty: %d\n", difficulty);
#endif

    setup(difficulty, mineLocation); //Place mines
    startSafe(mineLocation, safeSpots); //Place initial safe spots
    flagsLeft = difficulty; //Apply number of flags to be placed
    minesLeft = difficulty; //Apply initial number of mines to be found

    //Run through arrays to check mine placement
#ifdef DEBUG1
    for(i=0;i<=ROW;i++){
        for(j=0;j<=COL;j++){
            if(mineLocation[i][j] == YESMINE){
                printf("[FROM MAIN] Mine at row %d, col %d\n",i,j);
            }
        }
    }
    printf("\n");
#endif
    
    //Loop until quit (q) or steps on mine
    while(command != 'q' && timmy == ALIVE){
        command = getchar(); //Get input command
        
        //Remove whitespace
        while(command=='\n'){
            command = getchar();
        }
        
        //Move timmy, mark safe spots (function handles input)
        if((move(points,command,xpos,ypos,mineLocation,safeSpots))==YESMINE){
            timmy = DEAD;
        }

                        //Place safe spot glif on map with display.h
        
        
        //Check if timmy reached the end of maze
        if(xtim == COL){
            pointScore+=10; //Update points with winning bonus
            break; //Exit game instance
        }
        
        //Apply flags, update score if correct
        if((flag(points,flags,command,xpos,ypos,mineLocation,flagLocation))
            ==YESMINE){
            minesLeft--; //Decrement number of mines left to be found
                        //Update number of mines left with display.h
                        //Update number of flags left with display.h
        }
        
//Check where flags are
#ifdef DEBUG4
for(i=0;i<=ROW;i++){
    for(j=0;j<=COL;j++){
        if(flagLocation[i][j] == YESFLAG && command != '\n'){
            printf("[FROM MAIN] Flag at row %d, col %d\n",i,j);
            printf("[FROM MAIN] Flags left: %d\n\n", flagsLeft);
        }
    }
}
#endif
        //Update number of points with display.h

        
        //Display number of adjacent mines with display.h
        adjacent=detect(xpos,ypos,mineLocation);
        
#ifdef DEBUG2
if(command != '\n'){
    printf("[FROM MAIN] ytim:%d, xtim:%d\n",ytim,xtim);
    printf("[FROM MAIN] Number of adjacent mines: %d\n\n", adjacent);
}
#endif

#ifdef DEBUG5
if(command!='\n'){
    printf("Score: %d\n\n", pointScore);
}
#endif
    } //End of while loop for game instance
} //End of while loop for overall game loop
}