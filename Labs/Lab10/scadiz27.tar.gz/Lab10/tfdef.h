/*      File : tfdef.h        *
 *      By   : Stephen Cadiz                *
 *      login: scadiz27    *
 *      team : hammahs         *
 *      Date : 10/25/18          */
#define TRUE 1
#define FALSE 0


